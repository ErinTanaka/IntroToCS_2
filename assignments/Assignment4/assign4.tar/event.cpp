/*********************************
 *Program Filename: event.cpp
 *Author: Erin Tanaka
 *Date: May 17, 2016
 *Description: Implementation for event class
 ********************************/
#include "event.h"
/*********************************
 *Function: event
 *Description: event default constructor
 *Parameters: none
 *Pre-Conditions: none
 *Post-Conditions: object made
 * ******************************/
event::event(){}

