/****************************************
 *Program: tiger.h
 *Author:Erin Tanaka
 *Date:5/6/16
 *Description:tiger class
 * ************************************/
#ifndef TIGER_H
#define TIGER_H
#include "animal.h"
class tiger : public animal{
   private:
   public:
      tiger();
      int bonus_payout(int);

};
#endif
