/***********************************
 *Program:penguin.h
 *Author:Erin Tanaka
 *Date:5/6/16
 *Description: penguin class
 * *******************************/
#ifndef PENGUIN_H
#define PENGUIN_H
#include "animal.h"
class penguin : public animal{
   public:
      penguin();

};
#endif
