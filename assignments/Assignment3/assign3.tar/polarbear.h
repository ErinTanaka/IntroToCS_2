/***********************************
 *Program:polarbear.h
 *Author:Erin Tanaka
 *Date:5/6/16
 *Description: polarbear class
 * *******************************/
#ifndef POLARBEAR_H
#define POLARBEAR_H
#include "animal.h"
class polarbear:public animal{
   public:
      polarbear();
};
#endif
