#ifndef CARD_H
#define CARD_H
#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
using namespace std;

struct card{
   int value;
   string suit;
};
#endif
